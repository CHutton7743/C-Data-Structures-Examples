#ifndef BIG_INTEGER_CPP
#define BIG_INTEGER_CPP
#include "BigInteger.h"

using namespace std;

/* InvalidArgumentException
This is meant to handle an error in case a string being input into the
BigInteger contains anything other than numbers or a '-' sign.  If a
BigInteger is created using an invalid string, the error is thrown and
the function returned without creating a BigInteger object.
*/
class IllegalArgumentException
{
  public:

    string what() const throw()
    {
      return "Input must only contain numbers and '-'";
    }
};

//Default constructor: calls the parent constructor to instantiate
//BigInteger as a child of the DLL class.  Sets the negative value
//to false by default.
BigInteger::BigInteger()
          : DoublyLinkedList<int>(), negative(false)
{
}

//String constructor: calls the parent constructor to instantiate
//BigInteger as a child of the DLL class.  Sets the negative value
//to true or false depending on whether or not the first character
//of the string is a negative sign or not.  An IllegalArgumentException
//is thrown if the input contains invalid characters.  This is tested
//using the isDigits() function found at the bottom of this file.
//Then, appends each character of the string to the BigInteger DLL
//and increments the length variable as necessary.
BigInteger::BigInteger(const string & input)
          : DoublyLinkedList<int>(), negative(input[0] == '-')
{
  try
  {
    if(!isDigits(input))
    {
      throw IllegalArgumentException();
    }
  }
  catch(const IllegalArgumentException& e)
  {
    cout << e.what() << '\n';
    return;
  }

  for(int i = 0; i < input.length(); i++)
  {
    if(i == 0 && input.at(i) == '-')
    {
      continue;
    }
    int digit = input.at(i) - '0';
    insertLast(digit);
  }
}

//Copy constructor: creates a new BigInteger with the same
//data values as the BigInteger passed in as a parameter.
BigInteger::BigInteger(const BigInteger & input)
          : DoublyLinkedList<int>(), negative(input.negative)
{
  Node<int>* runner = input.first;
  for(int i = 0; i < input.length; i++)
  {
    insertLast(runner->data);
    runner = runner->next;
  } 
}

//Destructor: starts at the front of the list, uses iterator to move
//forward one node, and deletes the node behind it until the entire
//DLL is deleted.
BigInteger::~BigInteger()
{
  while(iterator != NULL)
  {
    iterator = last->next;
    delete last;
    last = iterator;
  }
}

//negativity of the linked list is tracked as a variable to allow for
//the DLL to be created as a DLL<int>.  This returns true or false
//depending on whether the number is negative or positive.  This
//is used to determine how to properly add or subtract the numbers
//between two BigIntegers later on.
bool BigInteger::isNegative()
{
  return negative;
}

//Assignment Operator: sets a BigInteger equal to the 
//input BigInteger
BigInteger BigInteger::operator=(const BigInteger & input)
{
  if(length > 0)
  {
    clear();
  }
  Node<int>* output = input.first;
  for(int i = 0; i < input.length; i++)
  {
    insertLast(output->data);
    output = output->next;
  }
  return *this;
}

/*+ operator overload: this function returned a 40/40 adding
BigIntegers, then I decided to get some extra work and accuracy
from the program by adding in different checks to cover every
possible combination of positive and negative numbers being added
to larger or smaller numbers of varying positivity/negativity.
This ensures, for example, that a large negative number being added
to a smaller positive number results in a negative answer with the
correct value.

This function works by adding the last value of each of the two
BigIntegers plus the "carry" variable.  If that value is greater
than 10, the carry variable is set to 1, otherwise it is set to 0.
When the end of one list is reached, the remaining values of the other
list are pulled down, resulting in the answer.
*/
BigInteger BigInteger::operator+(BigInteger & RHS)
{
  if(negative && !RHS.negative)
  {
    BigInteger left(*this);
    left.negative = false;
    if(left == RHS)
    {
      BigInteger output("0");
      return output;
    }

    if(left > RHS)
    {
      BigInteger output = left - RHS;
      output.negative = true;
      return output;
    }

    BigInteger output = RHS - left;
    output.negative = false;
    return output;
  }

  if(!negative && RHS.negative)
  {
    BigInteger right(RHS);
    right.negative = false;
    if(*this == right)
    {
      BigInteger output("0");
      return output;
    }

    if(*this < right)
    {
      BigInteger output = right - *this;
      output.negative = true;
      return output;
    }

    BigInteger output = *this - RHS;
    output.negative = false;
    return output;
  }

  BigInteger output;
  RHS.setIteratorLast();
  setIteratorLast();

  int carry = 0;
  int result = 0;

  while(!RHS.isIteratorNULL() || !isIteratorNULL())
  {
    int left = 0;
    int right = 0;
    if(!RHS.isIteratorNULL())
    {
      right = RHS.getData();
    }
    if(!isIteratorNULL())
    {
      left = getData();
    }
    result = right + left + carry;
    output.insertFirst(result%10);
    if(result >= 10)
    {
      carry = 1;
    }
    else
    {
      carry = 0;
    }

    if(!RHS.isIteratorNULL())
    {      
      RHS.prev();
    }
    if(!isIteratorNULL())
    {
      prev();
    }
    result = 0;
  }
  
  if(carry == 1)
  {
    output.insertFirst(1);
  }

  if(negative && RHS.negative)
  {
    output.negative = true;
  }

  return output;
}

/*- operator overload: this function returned a 40/40 subtracting
BigIntegers, then I decided to get some extra work and accuracy
from the program by adding in different checks to cover every
possible combination of positive and negative numbers being subtracted
from larger or smaller numbers of varying positivity/negativity.
This ensures, for example, that a small negative number being subtracted
by a larger negative number results in a positive answer with the
correct value.

This function works by checking to see which number is larger, and setting
that equal to the left hand value.  This will result in a negative answer, and
we set that variable properly before returning.  First, we check that the LHS
is not less than 0.  If it is, we add 10 and "borrow" from the previous node
by subtracting 1 from it.  Then, from the back of each BigInteger, we do 
LHS - RHS.  If that value is less than 0, we add 10 to the value, append it 
to the resulting BigInteger, and subtract 1 from the value of the previous 
node of the LHS.  This loop continues until there are either no more nodes, 
or the LHS has nodes remaining, in which case they are brought down and appended
to the new BigInteger object.  The new BigInteger object will then be equal
to the value of the two numbers subtracted from each other.  Finally, we ensure
that there are no leading zeroes, and the output BigInteger is returned.
*/
BigInteger BigInteger::operator-(BigInteger & RHS)
{
  if(*this == RHS)
  {
    BigInteger output("0");
    return output;
  }

  if(negative && RHS.negative)
  {
    if(*this == RHS)
    {
      BigInteger output("0");
      return output;
    }

    BigInteger left(*this);
    left.negative = false;
    BigInteger right(RHS);
    right.negative = false;

    if(left > right)
    {
      BigInteger output = left - right;
      output.negative = true;
      return output;
    }

    if(left < right)
    {
      cout << "*this > RHS" << endl;
      BigInteger output = right - left;
      return output;
    }
  }

  if(negative && !RHS.negative)
  {
    BigInteger left(*this);
    left.negative = false;

    BigInteger output = left + RHS;
    output.negative = true;
    return output;
  }

  if(!negative && RHS.negative)
  {
    BigInteger right(RHS);
    right.negative = false;

    BigInteger output = *this + right;
    output.negative = false;
    return output;
  }

  BigInteger output;
  int result = 0;

  if(RHS > *this)
  {
    output = RHS - *this;
    output.negative = true;
    return output;
  }

  setIteratorLast();
  RHS.setIteratorLast();

  while(!RHS.isIteratorNULL() || !isIteratorNULL())
  {
    if(RHS.isIteratorNULL())
    {
      while(!isIteratorNULL())
      {
        output.insertFirst(getData());
        prev();
      }

      return output;
    }

    if(getData() < 0)
    {
      iterator->data += 10;
      iterator->prev->data -=1; //might overflow here
    }

    result = getData() - RHS.getData();
    if(result < 0)
    {
      result += 10;
      iterator->prev->data -= 1;
    }
      output.insertFirst(result);

    if(!RHS.isIteratorNULL())
    {      
      RHS.prev();
    }
    if(!isIteratorNULL())
    {
      prev();
    }
  }
  output.setIteratorFirst();
  while(output.getData() == 0)
  {
    output.deleteFirst();
  }
  return output;
}

//first checks to see if both numbers match positivity or negativity.
//Then, iterates through the list comparing each data value.  Returns
//false if any two values ever don't match.  Also checks to ensure that
//no remaining numbers exist, so that 123 won't accidentally return true
//if compared to 1234, for example.
bool BigInteger::operator==(BigInteger & input)
{
  if(input.negative != negative)
  {
    return false;
  }

  if(input.getLength() != getLength())
  {
    return false;
  }

  setIteratorFirst();
  input.setIteratorFirst();
  while(!isIteratorNULL() && !input.isIteratorNULL())
  {
    if(getData() != input.getData())
    {
      return false;
    }

    if(!hasNext() || !input.hasNext())
    {
      if((hasNext() && !input.hasNext()) || (!hasNext() && input.hasNext()))
      {
        return false;
      }
      break;
    }
    next();
    input.next();
  }

  return true;
}

//> operator overload: takes all variations of positive or negative
//values into account, and accurately returns whether or not the LHS is
//greater than the RHS.
bool BigInteger::operator>(BigInteger & input)
{
  if(negative && !input.negative)
  {
    return false;
  }

  if(!negative && input.negative)
  {
    return true;
  }

  if(!negative && !input.negative && (length - input.length) != 0)
  {
    return (length - input.length) > 0;
  }

  if(negative && input.negative && (length - input.length) != 0)
  {
    return (length - input.length) < 0;
  }

  setIteratorFirst();
  input.setIteratorFirst();
  while(getData() == input.getData())
  {
    next();
    input.next();
  }

  if(negative && input.negative)
  {
    return getData() < input.getData();
  }

  return getData() > input.getData();
}

//<>> operator overload: takes all variations of positive or negative
//values into account, and accurately returns whether or not the LHS is
//less than the RHS.
bool BigInteger::operator<(BigInteger & input)
{
  if(negative && !input.negative)
  {
    return true;
  }

  if(!negative && input.negative)
  {
    return false;
  }

  if(!negative && !input.negative && (length - input.length) != 0)
  {
    return (length - input.length) < 0;
  }

  if(negative && input.negative && (length - input.length) != 0)
  {
    return (length - input.length) > 0;
  }

  setIteratorFirst();
  input.setIteratorFirst();
  while(getData() == input.getData())
  {
    next();
    input.next();
  }

  if(negative && input.negative)
  {
    return getData() > input.getData();
  }

  return getData() < input.getData();
}

//>= operator overload: uses already-defined "==" overload and ">"
//overload to determine true or false.  If either ">" or "==" return
//true, then ">=" returns true as well.  Otherwise, returns false.
bool BigInteger::operator>=(BigInteger & input)
{
  if(*this == input)
  {
    return true;
  }

  if(*this > input)
  {
    return true;
  }

  return false;
}

//<>>= operator overload: uses already-defined "==" overload and "<"
//overload to determine true or false.  If either "<" or "==" return
//true, then "<=" returns true as well.  Otherwise, returns false.
bool BigInteger::operator<=(BigInteger & input)
{
  if(*this == input)
  {
    return true;
  }

  if(*this < input)
  {
    return true;
  }

  return false;
}

//print: helper function to print the values of the BigInteger.
//if the number is negative, then a '-' is printed at the start of
//the string.  Then we start at the first node and iterate through,
//printing each value and a "->" along the way until we reach the end.
//Finally, returns the boolean representing whether or not the number is
//positive or negative.
void BigInteger::print()
{
  if(isNegative())
  {
    cout << "- ";
  }
  setIteratorFirst();

  while(!isIteratorNULL())
  {
    cout << getData() << "->";
    next();
  }
  cout << "null" << endl;
  cout << "Is negative: " << negative << endl;
}

//output operator overload: if the BigInteger is negative,
//we first append a '-' to the output stream.  Then we iterate
//through the list starting from the front, appending each node's
//data to the output stream as we go, until we reach the end of the
//list.  Finally, the output stream is returned.
ostream& operator<<(ostream& os, BigInteger & input)
{
  if(input.isNegative())
  {
    os << '-';
  }

  input.setIteratorFirst();
  while(!input.isIteratorNULL())
  {
    os << input.getData();
    input.next();
  }
  return os;
}

//input operator overload: an ifstream object is created, and the open()
//function is called to select a file to read from.  Then, each line of
//the file is converted into a string, which is then passed into the BigInteger
//assignment operator, setting input equal to a BigInteger with the values of
//the myLine string.  Finally, the input stream is returned.
istream& operator>>(istream& is, BigInteger &input)
{
  ifstream myFile;
  myFile.open("test.txt");
  string myLine;
  if(myFile.is_open())
  {
    getline(myFile, myLine);
    is >> myLine;
    input = BigInteger(myLine);
  }
  else
  {
    cout << "Couldn't open file" << endl;
  }
  return is;
}

//isDigits: this function contains a string of all the characters which are
//allowed to populate a BigInteger object.  If the input string contains any
//characters not contained in the string from within the function, then we
//return false.  The constructor then knows to throw an Invalid Argument
//Exception.
bool BigInteger::isDigits(const string &input)
{
    return input.find_first_not_of("-0123456789") == string::npos;
}

#endif